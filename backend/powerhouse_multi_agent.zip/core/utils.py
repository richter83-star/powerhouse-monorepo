def now_ts():
    import time; return int(time.time())
